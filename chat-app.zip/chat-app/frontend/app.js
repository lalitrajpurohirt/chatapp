/*fetch("/api/test")
     .then(response=>response.json())
     .then(data=>{
      console.log("Response from backend:",data);
     })
     .catch(error=>{
      console.errror("error:",error);
     });*/

/*old code
fetch("/api/message", {
  method: "POST",
  headers: {
    "Content-Type": "application/json" // ✅ correct casing
  },
  body: JSON.stringify({
    message: text
  })
})
  .then(response => response.json())
  .then(data => {
    const replyDiv = document.createElement("div");
    replyDiv.classList.add("message", "received");
    replyDiv.innerText = data.reply;

    message.appendChild(replyDiv);   // message = chat container
    message.scrollTop = message.scrollHeight;
  })
  .catch(err => {
    console.error("Error:", err);
  });

console.log("js connected"); 

const sendBtn = document.getElementById("sendBtn");
const messageInput = document.getElementById("messageInput");
const messages = document.querySelector(".messages");

sendBtn.addEventListener("click", sendMessage);

function sendMessage() {
  const text = messageInput.value.trim();
  if (text === "") return;

  // create message
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message", "sent");
  messageDiv.innerText = text;

  messages.appendChild(messageDiv);
  messages.scrollTop = messages.scrollHeight;//scroll downup
  messageInput.value = "";

  // fake reply
  setTimeout(() => {//delay function js ka 
    const replyDiv = document.createElement("div");
    replyDiv.classList.add("message", "received");
    replyDiv.innerText = "This is a demo reply 🙂";
    messages.appendChild(replyDiv);
     messages.scrollTop = messages.scrollHeight;//scroll downup
  }, 1000);
}

messageInput.addEventListener("keydown",function(event){
    if(event.key === "Enter"){
        sendMessage();
    }
});

const typingstatus=document.getElementById("typingStatus");
let typingTimer;
messageInput.addEventListener("input",()=>{
  typingStatus.innerText="Admin is typing.....";

  clearTimeout(typingTimer);

  clearTimeout=setTimeout(()=>{
    typingStatus.innerText="";
  },1000);
});*/

//new code
console.log("js connected");

const sendBtn = document.getElementById("sendBtn");
const messageInput = document.getElementById("messageInput");
const messages = document.querySelector(".messages");
const typingStatus = document.getElementById("typingStatus");

let typingTimer;

sendBtn.addEventListener("click", sendMessage);

messageInput.addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    sendMessage();
  }
});

function sendMessage() {
  const text = messageInput.value.trim();
  if (text === "") return;

  // show sent message
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message", "sent");
  messageDiv.innerText = text;
  messages.appendChild(messageDiv);
  messages.scrollTop = messages.scrollHeight;
  messageInput.value = "";

  // ✅ FETCH MUST BE INSIDE THIS FUNCTION
  fetch("/api/message", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ message: text })
  })
    .then(res => res.json())
    .then(data => {
      const replyDiv = document.createElement("div");
      replyDiv.classList.add("message", "received");
      replyDiv.innerText = data.reply;
      messages.appendChild(replyDiv);
      messages.scrollTop = messages.scrollHeight;
    })
    .catch(err => {
      console.error("Fetch error:", err);
    });
}

// typing status
messageInput.addEventListener("input", () => {
  typingStatus.innerText = "Admin is typing...";

  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    typingStatus.innerText = "";
  }, 1000);
});
