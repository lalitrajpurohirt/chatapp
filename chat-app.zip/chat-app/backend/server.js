/*app.use(express.json());

const express = require("express");
const path = require("path");

const app = express();
//serve frontend folder
app.use(express.static(path.join("../frontend")));

app.get("/",(req,res)=>{
    res.sendFile(path.join("C:\\Users\\rajpu\\OneDrive\\Desktop\\projects\\chat-app\\frontend\\index.html"));

});

app.get("/api/test",(req,res)=>{
    res.json({
        mesage:"API is working",
        status:"success"
    });
});

app.post("/api/message",(req,res)=>{
    const userMessage=req.body.message;
    console.log("message from frontend:",userMessage);
    res.json({
        reply:"backend received:" + userMessage
    });
});

app.listen(5000,()=>{
    console.log("server running on http://localhost:5000");
});*/

const express = require("express");
const path = require("path");

const app = express(); // ✅ create app first

// middleware
app.use(express.json());

// serve frontend folder
app.use(express.static(path.join(__dirname, "../frontend")));

app.get("/", (req, res) => {
  res.sendFile(
    path.join(__dirname, "../frontend/index.html")
  );
});

app.get("/api/test", (req, res) => {
  res.json({
    message: "API is working",
    status: "success"
  });
});

app.post("/api/message", (req, res) => {
  const userMessage = req.body.message;
  console.log("message from frontend:", userMessage);

  res.json({
    reply: "backend received: " + userMessage
  });
});

app.listen(5000, () => {
  console.log("server running on http://localhost:5000");
});
