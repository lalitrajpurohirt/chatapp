const http = require('node:http');

const hostname = '127.0.0.1';
const port=3000;

const server = http.createserver((req,res)=>{
    res.statuscode = 200;
    res.setheader('content-type','text/plain');
    res.end('hello,world\n');
});

server.listen(port,hostname,()=>{
    console.log('server running at http://${hostname}:$(port}/');
});